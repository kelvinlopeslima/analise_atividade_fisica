# Activity Analysis

Um pacote simples para analisar hábitos de atividade física com base em registros de tempo, calorias e tipo de atividade. O objetivo é gerar insights como frequência, tipos mais comuns, e evolução semanal.

## Instalação


pip install activity